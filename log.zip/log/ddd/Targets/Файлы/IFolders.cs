﻿namespace youknowcaliber
{
    public interface IFolders
    {
        string Source { get; }
        string Target { get; }
    }
}